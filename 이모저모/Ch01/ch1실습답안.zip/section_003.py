# 이름 배종우 학번 1234567

print(2020)
print(100+(20*3.14)/5) # 수식연산 가능함
print("내이름은 배종우")
print(10, 20, 30)
year = 2020
month = 3
date = 2
print("오늘 날짜", year, month, date)
