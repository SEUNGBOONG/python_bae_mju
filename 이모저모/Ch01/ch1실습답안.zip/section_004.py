# section_004.py 변형문제

print("내 나이는 ", 20, "살")

year = 2020
month, date, day = 3, 2, "월"
print("오늘 날짜는 ", year, "년 ", month, "월 ", date, "일 ", day, "요일")
