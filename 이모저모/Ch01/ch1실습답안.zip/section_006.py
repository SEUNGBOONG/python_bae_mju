# section_006.py 의 변형 실습

print("Q)")
print("속도를 나타내는 공식은 v=at 이고")
print("이동거리를 나타내는 공식은 S=(1/2)at^2 이다")
print("가속도 a=10m/s^2 라며")
print("10초 후의 속도와 거리는?")
print("A)")

a = 10
t = 10
v = a*t
S = (1/2)*a*(t**2)

print("v =", v, "m/s")
print("S =", S, "m")
