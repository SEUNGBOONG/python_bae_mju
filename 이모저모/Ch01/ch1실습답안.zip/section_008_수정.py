# section_008.py 수정 실습

print("나도 함수야!")

length = len("내 이름은 홍길동입니다!")
print(length)

print()
print("11, 2, 63, 47, 50 중에서")

max_number = max(11, 2, 63, 47, 50)
print("최대값은", max_number)

min_number = min(11, 2, 63, 47, 50)
print("최소값은", min_number)

sum_number = sum([11, 2, 63, 47, 50])
print("합은", sum_number)

print("평균은", sum_number/5)
