# apink1.py

print('에이핑크 (Apink)는 대한민국의 6인조 걸 그룹')
print('apink1.py 파일이 실행되었다.')

print(__name__)
