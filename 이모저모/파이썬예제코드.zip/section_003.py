#section_003.py

print(2020)    # 2020을 출력한다
print(3 + 2)
print("반갑다 파이썬!")
