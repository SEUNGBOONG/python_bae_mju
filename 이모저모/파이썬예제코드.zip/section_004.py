#section_004.py

apple = 10
lemon, banana = 20, 50
fruit = apple + lemon + banana

print(apple)
print(banana)
print(fruit)

apple = 30
print(apple)
