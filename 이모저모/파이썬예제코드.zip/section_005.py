#section_005.py

add = 3 + 25
sub = 45 - 13
mul = 9 * 9
div = 3 / 2
div_int = 3 // 2
exp = 10 ** 3
mod = 101 % 10

print(add)
print(sub)
print(mul)
print(div)
print(div_int)
print(exp)
print(mod)
