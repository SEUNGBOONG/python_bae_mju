#section_006.py

print('안녕하세요.')
print("I love the Earth!")
print("내가 좋아하는 숫자는 1, 4, 7입니다.")

city = 'Seoul'
dosi = "미래 도시"
print(dosi)
print(city)
