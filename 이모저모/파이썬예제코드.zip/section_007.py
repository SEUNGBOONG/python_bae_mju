#section_007.py

number = 1
print(number)

num1 = 10; num2 = 20; num3 = 30
print(num1+num2+num3)

sum = 1 + 2 + 3 + \
    4 + 5 + 6 + \
    7 + 8 + 9
print(sum)

tup = (1 + 2 + 3 +
    4 + 5 + 6 +
    7 + 8 + 9)
print(tup)

color = ['red', 
    'blue', 
    'green']
print(color)
