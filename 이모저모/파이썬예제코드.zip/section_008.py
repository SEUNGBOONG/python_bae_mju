#section_008.py

print("안녕! 나도 함수야")

length = len("이 문자열의 길이는 얼마일까?")
print(length)

max_number = max(11, 2, 63, 47, 50)
print(max_number)
