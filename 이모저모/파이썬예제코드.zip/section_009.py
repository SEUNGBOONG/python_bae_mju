#section_009.py

print('회원가입 기본정보')
name = input()
age = input('나이를 입력하세요: ')

print('당신의 이름과 나이는 다음과 같습니다.')
print(name)
print(age)

