#section_010.py

import math

print(math.pi)
print(math.sqrt(16))

r = 10
cir = 2 * math.pi * r

print('반지름이 ', r, '인 원의 둘레는', cir,'이다.')
