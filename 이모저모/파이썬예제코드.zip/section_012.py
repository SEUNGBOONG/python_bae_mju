#section_012.py

x = 5

x = x + 1
print(x)

x += 1     # x = x + 1
print(x)

y = 10
y *= x    # y = y * x
print(y)
