#section_013.py

x = 5

x = x + 1 * 10    # x = x + (1 * 10)
print(x)

y = 42 - 1 + 1 - 10
print(y)

z = (x + y) * 6
print(z)
