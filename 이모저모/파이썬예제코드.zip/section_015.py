#section_015.py

age = 38
print(type(age))

bigNumber = 2**124
print(bigNumber)
print(type(bigNumber))

