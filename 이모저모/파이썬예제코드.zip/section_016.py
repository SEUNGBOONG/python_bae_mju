#section_016.py

pi = 3.14
print("변수 pi의 자료형은", type(pi))

pi = 3
print("변수 pi의 자료형은", type(pi))
