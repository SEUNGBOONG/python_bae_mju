#section_018.py

boot = True     # 참
print(boot)
print(type(boot))

boof = False    # 거짓
print(boof)
print(type(boof))
print()

print(20 > 13)  # 두 값의 비교의 결과는?
print(0 < 0)
print('안녕' == '안녕')     # 두 문자열이 같은가?
print()

birds = 3       # 숫자 3은 참? 거짓?
print(bool(birds))
birds = 0       # 숫자 0은 참? 거짓?
print(bool(birds))
