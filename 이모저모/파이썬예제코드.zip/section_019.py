#section_019.py

text1 = '문자열은 작은따옴표 또는 큰따옴표로 묶어서 만들 수 있다.'
print(type(text1))

text2 = '작은따옴표로 묶인 문자열 안에 큰따옴표(")는 문제 없네요'
print(text2)

text3 = "큰따옴표로 묶인 문자열 안에 작은따옴표(')는 문제 없네요"
print(text3)

text4 = '특수문자열은 \'이렇게\' 출력되요'
print(text4)



