#section_021.py

print("=" * 40)

print("Python은" + " 훌륭한 프로그래밍 언어이다")

head = "Python은"
tail = " 훌륭한 프로그래밍 언어이다"
string = head + tail
print(string)

str1 = "꿈"
str2 = "과"
str3 = "도"
str4 = "전"
print(str1 + str2 + " " + str3 + str4)

print("=" * 40)
