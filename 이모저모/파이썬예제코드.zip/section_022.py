#section_022.py

string = "NATURE"

print(string[0])
print(string[1])
print(string[5])

print(string[-1])
print(string[-2])
print(string[-6])

