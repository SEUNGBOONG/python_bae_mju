#section_023.py

string = "NATURE"
print("-" * 5 + "정방향" + "-" * 5)
print(string[0:5])
print(string[2:4])
print(string[2:])
print(string[:3])

print("-" * 5 + "역방향" + "-" * 5)
print(string[-4:-2])
print(string[-6:])
print(string[:-3])
