#section_024.py

string = "name"
print(string)

capital = string.upper()

print(capital)
print(string)

#string[0] = "N"    # 오류 발생



