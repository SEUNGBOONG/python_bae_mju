#section_026.py

count = [1, 2, 3, 4, 5]
cars = ['버스', '트럭', '승용차', '밴']
wondolar = [1000, '1달러', 2000, '2달러', 3000, '3달러']

print(count)
print(cars)
print(wondolar)

print(count[0])
print(cars[2])
print(wondolar[-1])
