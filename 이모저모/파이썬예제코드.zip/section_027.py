#section_027.py

cheeses = ['체다', '모짜렐라', '까망베르', '리코타']
print(cheeses)

cheeses[0] = '크림'
print(cheeses)

all = cheeses + ['블루']
print(all)
print(cheeses)
