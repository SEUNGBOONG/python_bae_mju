#section_028.py

bucket = ['세계일주', '악기 하나 배우기', '누군가의 후원자되기',
          '베스트셀러 작가']
print(bucket)

done = bucket[1:3]
print(done)

print(bucket[0:4])
