#section_031.py

floating = [12.837, 4.89, 4037.0, 11.19]

print(len(floating))
print(max(floating))
print(min(floating))
print(sum(floating))
print()

print(sorted(floating))
print(floating)

string = "python"
print(list(string))
