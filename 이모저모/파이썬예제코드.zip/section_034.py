#section_034.py

myTuple = (1, 2, [10, 20, 30])
print(myTuple)
#myTuple[0] = 5   # 오류 발생
#myTuple[2] = 9   # 오류 발생

myTuple[2][1] = 5
print(myTuple)

myTuple = ('p', 'y', 't', 'h', 'o', 'n')
print(myTuple)
