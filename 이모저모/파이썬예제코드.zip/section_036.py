#section_036.py

t_float = (120.09, 9.11, 2.8)
L_int = [1, 2, 3]

print(len(t_float))
print(max(t_float))
print(min(t_float))
print(sum(t_float))
print(sorted(t_float))
print(t_float)

print(tuple(L_int))

