#section_041.py

s_float = {1.0, 3.0, 2.0, 10.0}
print(s_float)
print()

print(0.0 in s_float)
print('a' not in s_float)
print()

print(len(s_float))
print(max(s_float))
print(min(s_float))
print(sum(s_float))
print(sorted(s_float))
print(s_float)
print()

print(set([1, 2, 3, 2, 3]))
