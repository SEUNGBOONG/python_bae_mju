#section_042.py

my_dict = {}
my_dict = {'fishing': '낚시질', 'fishing banks':'어초', 'fishing boat': '낚싯배'}
my_dict = {1: "수소", 2: "헬륨", 2: "리튬", 3: "리튬"}
print(my_dict)

my_dict = {"name": "mr. Kang", 14003: [3,2,0,1]}
my_dict = dict([(1, '서울'), (2, '부산')])
print(my_dict)

my_exo = {"name": "찬열", "age": 25, "manager": "SM", "job": "singer"}
print(my_exo)
print(type(my_exo))
