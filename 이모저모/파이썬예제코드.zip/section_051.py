#section_051.py

import turtle

t = turtle.pen() # 소문자 pen() 을 쓰면 나중에 에러가 남
t.shape("turtle")

rabbit = 50
carrot = 0

if rabbit :
    t.forward(100)
if carrot :
    t.forward(100)
t.backward(100)

