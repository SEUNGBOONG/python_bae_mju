#section_057.py

import turtle

t = turtle.Pen()
t.shape("turtle")

count = 0

while count < 4 :
    t.forward(100)
    t.left(90)
    
    count = count + 1

