#section_058.py

import turtle

star = turtle.Pen()
star.shape("turtle")

for i in [1, 2, 3, 4, 5]:
    star.forward(100)
    star.left(72)



   
