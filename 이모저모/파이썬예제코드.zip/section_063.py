#section_063.py

def simple():
    pass

print(simple())
