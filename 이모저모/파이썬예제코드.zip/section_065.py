#section_065.py

def sayhello():
    print('안녕')
    print('반가워. 이 프로그램은 파이썬 공부 프로그램이야')
    print('기분 좋은 하루 보내~')

sayhello()
sayhello()

