#section_067.py

def hap(a, b):
    result = a + b
    print('두 수의 합을 구해 출력해주는 함수입니다')
    print(a, b, '의 합은 ', result, '입니다')

hap(10, 20)
hap(-87, 172)

