#section_069.py

def report(message, who='Everyone'):
    print(message, who)

report('good morning')
report('good morning', 'Mr. Park')
