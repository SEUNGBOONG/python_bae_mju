#section_076.py

pos = 10
neg = -10

print(abs(pos))
print(abs(neg))

if neg > 0 :
    print('뒷 걸음질 치다')
if abs(neg) > 0 :
    print('전진하다')

    
