#section_078.py

myList = [1, 2, 3]

print(dir())
input()
print('-' * 50)

print(dir(myList))
input()
print('-' * 50)

print(help(myList.append))
input()
print('-' * 50)

print(help(myList))
