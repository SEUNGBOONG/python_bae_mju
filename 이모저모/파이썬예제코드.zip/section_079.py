#section_079.py

print(eval('1000 * 2'))

number = 1
exp = 'print(number + 1)'
eval(exp)
