#section_082.py

print(float())

print(float(-10))
print(float('10'))

print(float('3.14'))

