#section_083.py

print(int())
print(int(10))

print(int(3.74))
print(int('1234'))
