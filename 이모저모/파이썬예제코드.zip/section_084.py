#section_084.py

print('문자열:', len('python'))

myList = [1, 2, 3, 4, 5, 6, 7]
print('리스트:', len(myList))

myDict = {0:'호날두', 1:'메시', 2:'손흥민'} 
for item in range(len(myDict)):
    print('사전',item,':', myDict[item])
