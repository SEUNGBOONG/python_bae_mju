#section_085.py

print(pow(10, 2))

print(round(2.3), round(4.6))

myList = [1, 2, 3, 4, 5, 6]
print(sum(myList))
