#section_086.py

myTup = (56, 79, 82, 1, 22, 99)
print(max(myTup), min(myTup))

print('영문자 중 가장 큰 문자:', max('abcde'))
print('서로 다른 문자들 중 큰 문자:', max('0Aa'))

print('문장 속 최댓값 문자:', max('I went to the zoo yesterday, 27 March.'))
print('문장 속 최솟값 문자:', min('I went to the zoo yesterday, 27 March.'))

