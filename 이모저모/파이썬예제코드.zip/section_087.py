#section_087.py

import myMath
import math

print('내가 만든 모듈 사용 예제')

print(myMath.pi)
print(math.pi)

print('1부터 10까지의 합:', myMath.oneHapN(10))
print('1부터 10까지의 곱:', myMath.oneGopN(10))


