#section_088.py

import apink1
