#section_090.py

import keyword

print(keyword.iskeyword('None'))
print(keyword.iskeyword('int'))
print(keyword.kwlist)

