#section_091.py

import random

for i in range(6):
    number = random.randint(1, 45)
    print(number, end=' ')
