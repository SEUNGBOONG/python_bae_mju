#section_093.py

import random

myStr = "최고의영화-죽은시인의사회"
print(random.sample(myStr, 3))

myList = random.sample(range(1,46), 6)
myList.sort()
print(myList)

