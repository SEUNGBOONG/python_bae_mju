#section_094.py

import random

print(random.random())

print(random.uniform(0, 10))
