#section_097.py

import time

for t in range(6):
    print(time.ctime())
    time.sleep(1)
