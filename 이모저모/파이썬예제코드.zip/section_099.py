#section_099.py

f = open('myfile.txt', 'w')

f.close()
