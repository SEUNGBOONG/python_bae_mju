#section_100.py

f = open('c:/temp/myfile.txt', 'w')

memo = '파일을 열었으니 데이터를 저장하자'
f.write(memo)

f.close()
