#section_107.py

name = '휴보'
weight = 45

def speak():
    print('안녕하세요. 휴보입니다.')

def move():
    print('휴보가 이동한다')
