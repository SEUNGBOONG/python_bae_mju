#section_109.py


a = 10
print(type(a))

b = int(10)
print(type(b))

c = [1, 2, 3, 4, 5]
print(type(c))

def func(x):
    return x + 1
print(type(func))

import math
print(type(math))
