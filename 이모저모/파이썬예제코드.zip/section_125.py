#section_125.py

try:
    raise IndexError
except IndexError:
    print('인덱스 에러 발생')    
